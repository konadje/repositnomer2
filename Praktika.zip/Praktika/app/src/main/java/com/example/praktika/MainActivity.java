package com.example.praktika;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listViewNotes;
    private TextView textViewSelectedNote;
    private Button buttonDelete, buttonAdd, buttonAbout, buttonExit;
    private DatabaseHelper db;
    private List<Note> notesList;
    private int selectedNoteId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        initViews();
        setupListeners();
        loadNotes();
    }

    private void initViews() {
        listViewNotes = findViewById(R.id.listViewNotes);
        textViewSelectedNote = findViewById(R.id.textViewSelectedNote);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonAbout = findViewById(R.id.buttonAbout);
        buttonExit = findViewById(R.id.buttonExit);
    }

    private void setupListeners() {
        listViewNotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Note selectedNote = notesList.get(position);
                selectedNoteId = selectedNote.getId();
                textViewSelectedNote.setText(selectedNote.getTitle() + "\n" + selectedNote.getContent());
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedNoteId != -1) {
                    db.deleteNote(selectedNoteId);
                    loadNotes();
                    textViewSelectedNote.setText("(формируется по нажатию на конкретный элемент списка)");
                    selectedNoteId = -1;
                    Toast.makeText(MainActivity.this, "Запись удалена", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Выберите запись для удаления", Toast.LENGTH_SHORT).show();
                }
            }
        });
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, NotepadActivity.class));
            }
        });

        buttonAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AboutActivity.class));
            }
        });

        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    private void loadNotes() {
        notesList = db.getAllNotes();
        ArrayAdapter<Note> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, notesList);
        listViewNotes.setAdapter(adapter);
    }
    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }
}